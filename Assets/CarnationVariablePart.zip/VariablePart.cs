﻿using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using System.Threading;
using System.Collections.Generic;

namespace CarnationVariablePart
{
    public partial class VariablePart
    {
        public float Section0Width
        {
            get => _Section0Width;
            set => _Section0Width = Mathf.Abs(value);
        }
        public float Section0Height
        {
            get => _Section0Height;
            set => _Section0Height = Mathf.Abs(value);
        }
        public float Section1Width
        {
            get => _Section1Width;
            set => _Section1Width = Mathf.Abs(value);
        }
        public float Section1Height
        {
            get => _Section1Height;
            set => _Section1Height = Mathf.Abs(value);
        }
        public float Length
        {
            get => _Length;
            set => _Length = Mathf.Abs(value);
        }
        public float Run, Raise;
        public float Twist
        {
            get => _Twist;
            set => _Twist = Mathf.Clamp(value, -45f, 45f);
        }
        //public Transform Secttion1LoaclTransform
        //{
        //    get;
        //    protected set;
        //}
        public float[] CornerRadius
        {
            get => meshBuilder.roundRadius;
            set => meshBuilder.roundRadius = value;
        }
        public bool CornerUVCorrection { get; set; }
        public bool RealWorldMapping { get; set; }
        public bool SectionTiledMapping { get; set; }

        VariablePartMesh meshBuilder;
        delegate void DelUpdate();
        static DelUpdate del;
        private bool requestUpdate = false;

        private static List<VariablePart> instance = new List<VariablePart>();
        private float _Twist;
        private float _Section0Width;
        private float _Section0Height;
        private float _Section1Width;
        private float _Section1Height;
        private float _oldSection0Width;
        private float _oldSection0Height;
        private float _oldSection1Width;
        private float _oldSection1Height;
        private float _Length;

        static VariablePart()
        {
            //del = new DelUpdate(UpdateQueue);
            //  del.BeginInvoke(null, null);
        }
        public VariablePart(MeshFilter mf)
        {
            meshBuilder = new VariablePartMesh(mf, this);
            if (meshBuilder == null) throw new Exception();
            LoadParams();
            new Thread(UpdateQueue).Start();
            Update();
            instance.Add(this);
            for (int i = 0; i < instance.Count; i++)
                if (instance[i] == null)
                    instance.RemoveAt(i);
        }

        private void LoadParams()
        {
            Length = 2f;
            Section0Width = 2;
            Section1Height = 2;
            Section1Width = 2;
            Section0Height = 2;
            Run = 0;
            Raise = 0;
            Twist = 0;
        }
        public void Update()
        {
            requestUpdate = true;
            meshBuilder.Update();
        }

        private static void UpdateQueue()
        {
            return;
            while (true)
            {
                foreach (var i in instance)
                {
                    if (i.requestUpdate)
                        i.meshBuilder.Update();
                    i.requestUpdate = false;
                }
            }
        }
    }
}