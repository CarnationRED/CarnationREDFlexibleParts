﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using CarnationVariablePart;
[ExecuteInEditMode]
public partial class VariablePartTest : MonoBehaviour
{
    public Texture tex;

    public bool UseTexture = false;
    public bool RealWorldMapping = false;
    public bool CornerUVCorrection = false;
    public bool SectionTiledMapping = false;
    [Range(0f, 1f)]
    public float roundRadius0 = 0f;
    [Range(0f, 1f)]
    public float roundRadius1 = 0f;
    [Range(0f, 1f)]
    public float roundRadius2 = 0f;
    [Range(0f, 1f)]
    public float roundRadius3 = 0f;
    [Range(0f, 1f)]
    public float roundRadius4 = 0f;
    [Range(0f, 1f)]
    public float roundRadius5 = 0f;
    [Range(0f, 1f)]
    public float roundRadius6 = 0f;
    [Range(0f, 1f)]
    public float roundRadius7 = 0f;
    [Range(-45f, 45f)]
    public float Twist = 0;
    [Range(0, 5f)]
    public float Section0Width = 2f;
    [Range(0, 5f)]
    public float Section0Height = 2f;
    [Range(0, 5f)]
    public float Section1Width = 2f;
    [Range(0, 5f)]
    public float Section1Height = 2f;

    VariablePart part;

    private void Start()
    {
        //使用旧版兼容的方法
        MeshFilter m;
        //m = GetComponent<MeshFilter>();
        //if (m != null)
        if (TryGetComponent<MeshFilter>(out m))
            DestroyImmediate(m);
        m = gameObject.AddComponent<MeshFilter>();
        part = new VariablePart(m);
        if (part == null) throw new Exception();
    }
    private void Update()
    {
        if (part == null) Start();
        if (TryGetComponent<Renderer>(out Renderer r))
        {
            if (UseTexture)
            {
                if (r.sharedMaterials[0].mainTexture == null)
                    r.sharedMaterials[0].mainTexture = tex;
            }
            else
                r.sharedMaterials[0].mainTexture = null;
        }
        part.CornerRadius[0] = roundRadius0;
        part.CornerRadius[1] = roundRadius1;
        part.CornerRadius[2] = roundRadius2;
        part.CornerRadius[3] = roundRadius3;
        part.CornerRadius[4] = roundRadius4;
        part.CornerRadius[5] = roundRadius5;
        part.CornerRadius[6] = roundRadius6;
        part.CornerRadius[7] = roundRadius7;
        part.Twist = Twist;
        part.Section0Width = Section0Width;
        part.Section0Height = Section0Height;
        part.Section1Width = Section1Width;
        part.Section1Height = Section1Height;
        part.RealWorldMapping = RealWorldMapping;
        part.CornerUVCorrection = CornerUVCorrection;
        part.SectionTiledMapping = SectionTiledMapping;

        part.Update();
        System.Threading.Thread.Sleep(50);
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(50, 50, 150, 50), "time:" + Time.deltaTime);
    }
}