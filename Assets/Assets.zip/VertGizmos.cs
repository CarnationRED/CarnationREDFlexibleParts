﻿using System;
using System.IO;
using UnityEditor;
using UnityEngine;

[ExecuteInEditMode]
public class VertGizmos : MonoBehaviour
{

    public string VertiStr = "";
    private static readonly Vector3[] verts_origin = { new Vector3(-1.0f, 1.0f, 0.6666666f), new Vector3(-1.0f, 1.0f, 1.0f), new Vector3(1.0f, 1.0f, 1.0f), new Vector3(1.0f, 1.0f, 0.6666666f), new Vector3(-1.0f, 1.0f, 0.3333333f), new Vector3(1.0f, 1.0f, 0.3333333f), new Vector3(-1.0f, 1.0f, 0.1f), new Vector3(1.0f, 1.0f, 0.1f), new Vector3(-1.0f, 1.0f, -0.1f), new Vector3(1.0f, 1.0f, -0.1f), new Vector3(-1.0f, 1.0f, -0.3333333f), new Vector3(1.0f, 1.0f, -0.3333333f), new Vector3(-1.0f, 1.0f, -0.6666666f), new Vector3(1.0f, 1.0f, -0.6666666f), new Vector3(-1.0f, 1.0f, -1.0f), new Vector3(1.0f, 1.0f, -1.0f), new Vector3(1.0f, -1.0f, -1.0f), new Vector3(-1.0f, -1.0f, -1.0f), new Vector3(-1.0f, -0.6666666f, -1.0f), new Vector3(1.0f, -0.6666666f, -1.0f), new Vector3(-1.0f, -0.3333333f, -1.0f), new Vector3(1.0f, -0.3333333f, -1.0f), new Vector3(-1.0f, -0.1f, -1.0f), new Vector3(1.0f, -0.1f, -1.0f), new Vector3(1.0f, 0.1f, -1.0f), new Vector3(-1.0f, 0.1f, -1.0f), new Vector3(-1.0f, 0.3333333f, -1.0f), new Vector3(1.0f, 0.3333333f, -1.0f), new Vector3(-1.0f, 0.6666666f, -1.0f), new Vector3(1.0f, 0.6666666f, -1.0f), new Vector3(-1.0f, 1.0f, -1.0f), new Vector3(1.0f, 1.0f, -1.0f), new Vector3(-1.0f, -1.0f, 1.0f), new Vector3(1.0f, -1.0f, 1.0f), new Vector3(1.0f, -0.6666666f, 1.0f), new Vector3(-1.0f, -0.6666666f, 1.0f), new Vector3(1.0f, -0.3333333f, 1.0f), new Vector3(-1.0f, -0.3333333f, 1.0f), new Vector3(1.0f, -0.1f, 1.0f), new Vector3(-1.0f, -0.1f, 1.0f), new Vector3(-1.0f, 0.1f, 1.0f), new Vector3(1.0f, 0.1f, 1.0f), new Vector3(1.0f, 0.3333333f, 1.0f), new Vector3(-1.0f, 0.3333333f, 1.0f), new Vector3(1.0f, 0.6666666f, 1.0f), new Vector3(-1.0f, 0.6666666f, 1.0f), new Vector3(1.0f, 1.0f, 1.0f), new Vector3(-1.0f, 1.0f, 1.0f), new Vector3(1.0f, -1.0f, 0.6666666f), new Vector3(1.0f, -1.0f, 1.0f), new Vector3(-1.0f, -1.0f, 1.0f), new Vector3(-1.0f, -1.0f, 0.6666666f), new Vector3(1.0f, -1.0f, 0.3333333f), new Vector3(-1.0f, -1.0f, 0.3333333f), new Vector3(1.0f, -1.0f, 0.1f), new Vector3(-1.0f, -1.0f, 0.1f), new Vector3(1.0f, -1.0f, -0.1f), new Vector3(-1.0f, -1.0f, -0.1f), new Vector3(1.0f, -1.0f, -0.3333333f), new Vector3(-1.0f, -1.0f, -0.3333333f), new Vector3(1.0f, -1.0f, -0.6666666f), new Vector3(-1.0f, -1.0f, -0.6666666f), new Vector3(1.0f, -1.0f, -1.0f), new Vector3(-1.0f, -1.0f, -1.0f), new Vector3(-1.0f, -0.6666666f, 1.0f), new Vector3(-1.0f, -1.0f, 0.6666666f), new Vector3(-1.0f, -1.0f, 1.0f), new Vector3(-1.0f, 0.0f, 0.0f), new Vector3(-1.0f, -0.3333333f, 1.0f), new Vector3(-1.0f, -1.0f, 0.3333333f), new Vector3(-1.0f, -0.1f, 1.0f), new Vector3(-1.0f, -1.0f, 0.1f), new Vector3(-1.0f, 0.1f, 1.0f), new Vector3(-1.0f, -1.0f, -0.1f), new Vector3(-1.0f, 0.3333333f, 1.0f), new Vector3(-1.0f, -1.0f, -0.3333333f), new Vector3(-1.0f, 0.6666666f, 1.0f), new Vector3(-1.0f, -1.0f, -0.6666666f), new Vector3(-1.0f, 1.0f, 1.0f), new Vector3(-1.0f, -1.0f, -1.0f), new Vector3(-1.0f, 1.0f, 0.6666666f), new Vector3(-1.0f, -0.6666666f, -1.0f), new Vector3(-1.0f, 1.0f, 0.3333333f), new Vector3(-1.0f, -0.3333333f, -1.0f), new Vector3(-1.0f, 1.0f, 0.1f), new Vector3(-1.0f, -0.1f, -1.0f), new Vector3(-1.0f, 1.0f, -0.1f), new Vector3(-1.0f, 0.1f, -1.0f), new Vector3(-1.0f, 1.0f, -0.3333333f), new Vector3(-1.0f, 0.3333333f, -1.0f), new Vector3(-1.0f, 1.0f, -0.6666666f), new Vector3(-1.0f, 0.6666666f, -1.0f), new Vector3(-1.0f, 1.0f, -1.0f), new Vector3(1.0f, -0.6666666f, -1.0f), new Vector3(1.0f, -1.0f, -0.6666666f), new Vector3(1.0f, -1.0f, -1.0f), new Vector3(1.0f, 0.0f, 0.0f), new Vector3(1.0f, -0.3333333f, -1.0f), new Vector3(1.0f, -1.0f, -0.3333333f), new Vector3(1.0f, -0.1f, -1.0f), new Vector3(1.0f, -1.0f, -0.1f), new Vector3(1.0f, 0.1f, -1.0f), new Vector3(1.0f, -1.0f, 0.1f), new Vector3(1.0f, 0.3333333f, -1.0f), new Vector3(1.0f, -1.0f, 0.3333333f), new Vector3(1.0f, 0.6666666f, -1.0f), new Vector3(1.0f, -1.0f, 0.6666666f), new Vector3(1.0f, 1.0f, -1.0f), new Vector3(1.0f, -1.0f, 1.0f), new Vector3(1.0f, 1.0f, -0.6666666f), new Vector3(1.0f, -0.6666666f, 1.0f), new Vector3(1.0f, 1.0f, -0.3333333f), new Vector3(1.0f, -0.3333333f, 1.0f), new Vector3(1.0f, 1.0f, -0.1f), new Vector3(1.0f, -0.1f, 1.0f), new Vector3(1.0f, 1.0f, 0.1f), new Vector3(1.0f, 0.1f, 1.0f), new Vector3(1.0f, 1.0f, 0.3333333f), new Vector3(1.0f, 0.3333333f, 1.0f), new Vector3(1.0f, 1.0f, 0.6666666f), new Vector3(1.0f, 0.6666666f, 1.0f), new Vector3(1.0f, 1.0f, 1.0f) };
    private static readonly Vector2[] uv_origin = { new Vector2(3.833266f, 1f), new Vector2(4f, 1f), new Vector2(4f, 0f), new Vector2(3.833266f, 0f), new Vector2(3.666634f, 1f), new Vector2(3.666634f, 0f), new Vector2(3.55f, 1f), new Vector2(3.55f, 0f), new Vector2(3.45f, 1f), new Vector2(3.45f, 0f), new Vector2(3.333366f, 1f), new Vector2(3.333366f, 0f), new Vector2(3.166734f, 1f), new Vector2(3.166734f, 0f), new Vector2(3.0f, 1f), new Vector2(3.0f, 0f), new Vector2(2.0f, 0f), new Vector2(2.0f, 1f), new Vector2(2.166733f, 1f), new Vector2(2.166733f, 0f), new Vector2(2.333365f, 1f), new Vector2(2.333366f, 0f), new Vector2(2.450009f, 1f), new Vector2(2.45f, 0f), new Vector2(2.55f, 0f), new Vector2(2.55f, 1f), new Vector2(2.666634f, 1f), new Vector2(2.666633f, 0f), new Vector2(2.833266f, 1f), new Vector2(2.833266f, 0f), new Vector2(2.999899f, 1f), new Vector2(2.9999f, 0f), new Vector2(1f, 1f), new Vector2(1f, 0f), new Vector2(0.833266f, 0f), new Vector2(0.833266f, 1f), new Vector2(0.666634f, 0f), new Vector2(0.666634f, 1f), new Vector2(0.55f, 0f), new Vector2(0.55f, 1f), new Vector2(0.45f, 1f), new Vector2(0.45f, 0f), new Vector2(0.333366f, 0f), new Vector2(0.333366f, 1f), new Vector2(0.166734f, 0f), new Vector2(0.166733f, 1f), new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(1.166734f, 0f), new Vector2(1.0f, 0f), new Vector2(1.0f, 1f), new Vector2(1.166734f, 1f), new Vector2(1.333366f, 0f), new Vector2(1.333366f, 1f), new Vector2(1.45f, 0f), new Vector2(1.45f, 1f), new Vector2(1.55f, 0f), new Vector2(1.55f, 1f), new Vector2(1.666634f, 0f), new Vector2(1.666634f, 1f), new Vector2(1.833266f, 0f), new Vector2(1.833266f, 1f), new Vector2(1.9999f, 0f), new Vector2(1.9999f, 1f), new Vector2(0f, 0.166734f), new Vector2(0.166735f, 0f), new Vector2(0f, 0f), new Vector2(0.5f, 0.5f), new Vector2(0f, 0.333366f), new Vector2(0.333367f, 0f), new Vector2(0f, 0.45f), new Vector2(0.451f, 0f), new Vector2(0f, 0.55f), new Vector2(0.549991f, 0f), new Vector2(0f, 0.666634f), new Vector2(0.666633f, 0f), new Vector2(0f, 0.833266f), new Vector2(0.833265f, 0f), new Vector2(0f, 1f), new Vector2(0.999899f, 0f), new Vector2(0.166734f, 1f), new Vector2(0.999899f, 0.166734f), new Vector2(0.333366f, 1f), new Vector2(0.999899f, 0.333366f), new Vector2(0.45f, 1f), new Vector2(1f, 0.45f), new Vector2(0.55f, 1f), new Vector2(1f, 0.55f), new Vector2(0.666634f, 1f), new Vector2(1f, 0.666634f), new Vector2(0.833266f, 1f), new Vector2(1f, 0.833266f), new Vector2(1f, 1f), new Vector2(0f, 0.166734f), new Vector2(0.166735f, 0f), new Vector2(0f, 0f), new Vector2(0.5f, 0.5f), new Vector2(0f, 0.333366f), new Vector2(0.333367f, 0f), new Vector2(0f, 0.45f), new Vector2(0.451f, 0f), new Vector2(0f, 0.55f), new Vector2(0.549991f, 0f), new Vector2(0f, 0.666634f), new Vector2(0.666634f, 0f), new Vector2(0f, 0.833266f), new Vector2(0.833265f, 0f), new Vector2(0f, 1f), new Vector2(0.999899f, 0f), new Vector2(0.166734f, 1f), new Vector2(0.999899f, 0.166734f), new Vector2(0.333366f, 1f), new Vector2(0.999899f, 0.333366f), new Vector2(0.45f, 1f), new Vector2(1f, 0.45f), new Vector2(0.55f, 1f), new Vector2(1f, 0.55f), new Vector2(0.666634f, 1f), new Vector2(1f, 0.666634f), new Vector2(0.833266f, 1f), new Vector2(1f, 0.833266f), new Vector2(1f, 1f) };
    private static readonly int[] tris = new int[] {
                0,  1, 2,
                0,  2, 3,
                4,  0, 3,
                4,  3, 5,
                6,  4, 5,
                6,  5, 7,
                8,  6, 7,
                8,  7, 9,
                10, 8, 9,
                10, 9,11,
                12,10,11,
                12,11,13,
                14,12,13,
                14,13,15,
                16,17,18,
                16,18,19,
                19,18,20,
                19,20,21,
                21,20,22,
                21,22,23,
                22,24,23,
                22,25,24,
                24,25,26,
                24,26,27,
                27,26,28,
                27,28,29,
                29,28,30,
                29,30,31,
                32,33,34,
                32,34,35,
                35,34,36,
                35,36,37,
                37,36,38,
                37,38,39,
                38,40,39,
                38,41,40,
                40,41,42,
                40,42,43,
                43,42,44,
                43,44,45,
                45,44,46,
                45,46,47,
                48,49,50,
                48,50,51,
                52,48,51,
                52,51,53,
                54,52,53,
                54,53,55,
                56,54,55,
                56,55,57,
                58,56,57,
                58,57,59,
                60,58,59,
                60,59,61,
                62,60,61,
                62,61,63,
                64,65,66,
                64,67,65,
                68,67,64,
                67,69,65,
                70,67,68,
                67,71,69,
                70,72,67,
                73,71,67,
                74,67,72,
                67,75,73,
                76,67,74,
                67,77,75,
                78,67,76,
                67,79,77,
                78,80,67,
                67,81,79,
                80,82,67,
                67,83,81,
                82,84,67,
                67,85,83,
                67,84,86,
                67,87,85,
                86,88,67,
                67,89,87,
                88,90,67,
                67,91,89,
                90,91,67,
                90,92,91,
                93,94,95,
                93,96,94,
                97,96,93,
                96,98,94,
                99,96,97,
                96,100,98,
                99,101,96,
                102,100,96,
                103,96,101,
                96,104,102,
                105,96,103,
                96,106,104,
                107,96,105,
                96,108,106,
                107,109,96,
                96,110,108,
                109,111,96,
                96,112,110,
                111,113,96,
                96,114,112,
                96,113,115,
                96,116,114,
                115,117,96,
                96,118,116,
                117,119,96,
                96,120,118,
                119,120,96,
                119,121,120};

    /// <summary>
    /// 前后截面上的8个角对应的点id
    /// </summary>
    private int[][] sectionCorners = { new int[] { 116, 118, 120, 121, 119, 117, 115 }, new int[] { 113, 111, 109, 107, 105, 103, 101 }, new int[] {99,97,93,95,94,98,100 }, new int[] { 102,104,106,108,110,112,114} ,
                                       new int[] {  72,  74,  76,  78,  80,  82,  84 }, new int[] {  86,  88,  90,  92,  91,  89,  87 }, new int[] {85,83,81,79,77,75, 73 }, new int[] {  71, 69, 65, 66, 64, 68, 70} };
    /// <summary>
    /// 每个角相对于第一象限旋转的角度
    /// </summary>
    private int[] sectionCornersRotation = { 0, 90, 180, 270, 0, 90, 180, 270 };

    /// <summary>
    /// 极坐标单位圆上+0°~+90°对应点的直角坐标
    /// </summary>
    private static Vector2[] roundCorner = {
        new Vector2(1f, 0f),
        new Vector2(0.9659258f, 0.2588190f),
        new Vector2(0.8660254f, 0.5f),
        new Vector2(0.7071067f, 0.7071067f),
        new Vector2(0.5f, 0.8660254f),
        new Vector2(0.2588190f, 0.9659258f),
        new Vector2(0f, 1f) };
    private Vector3[] vertices;
    private Vector2[] uv;
    private int[] triangles;

    [Range(0f, 1f)]
    public float roundRadius = 0f;

    public bool useImportModel = false;

    private float oldRoundRadius = 0f;

    private Mesh mesh;
    private void Start()
    {
        if (useImportModel)
        {
            mesh = GetComponent<MeshFilter>().mesh;
            InstantiateMesh(mesh.vertices, mesh.uv);
            DestroyImmediate(GetComponent<MeshFilter>());
            var mf = gameObject.AddComponent<MeshFilter>();
            mesh = mf.mesh;
            mesh.vertices = vertices;
            mesh.triangles = tris;
            mesh.uv = uv;
        }
        else
        {
            if (TryGetComponent<MeshFilter>(out MeshFilter m))
                DestroyImmediate(m);
            var mf = gameObject.AddComponent<MeshFilter>();
            mesh = mf.mesh;
            mesh.vertices = verts_origin;
            mesh.triangles = tris;
            mesh.uv = uv_origin;
            InstantiateMesh();
        }
    }

    private void InstantiateMesh()
    {
        InstantiateMesh(verts_origin, uv_origin);
    }
    private void InstantiateMesh(Vector3[] vs, Vector2[] uv)
    {
        vertices = new Vector3[vs.Length];
        vs.CopyTo(vertices, 0);
        this.uv = new Vector2[uv.Length];
        uv.CopyTo(this.uv, 0);
    }
    private void ApplyVertices()
    {
        mesh.vertices = vertices;
    }
    private void ApplyUVs()
    {
        mesh.uv = uv;
    }
    private void ApplyMesh()
    {
        mesh.RecalculateNormals();
        mesh.RecalculateTangents();
    }
    private void RoundCorner(int cornerID, float radiusNormalized)
    {
        //顶点ID
        var corner = sectionCorners[cornerID];
        if (Mathf.Abs(radiusNormalized) < 1e-4f)
        {
            for (int i = 0; i < corner.Length; i++)
            {
                vertices[corner[i]].z = verts_origin[corner[i]].z;
                vertices[corner[i]].y = verts_origin[corner[i]].y;
            }
            return;
        }
        //旋转矩阵
        float xx, xy, yy, yx;
        switch (sectionCornersRotation[cornerID])
        {
            case 90:
                xx = 0;
                xy = 1;
                yy = 0;
                yx = -1;
                break;
            case 180:
                xx = -1;
                xy = 0;
                yy = -1;
                yx = 0;
                break;
            case 270:
                xx = 0;
                xy = -1;
                yy = 0;
                yx = 1;
                break;
            default:    //0
                xx = 1;
                xy = 0;
                yy = 1;
                yx = 0;
                break;
        }
        Vector2 center = new Vector2(xx + yx, xy + yy) * (1 - radiusNormalized);
        for (int i = 0; i < corner.Length; i++)
        {
            vertices[corner[i]].z = center.x + radiusNormalized * (roundCorner[i].x * xx + roundCorner[i].y * yx);
            vertices[corner[i]].y = center.y + radiusNormalized * (roundCorner[i].x * xy + roundCorner[i].y * yy);
        }
    }
    private void GenerateBody()
    {
        throw new NotImplementedException();
    }
    private void CorrectUVs()
    {
        for (int i = 0; i < sectionCorners.Length; i++)
        {
            var corner = sectionCorners[i];
            for (int j = 0; j < corner.Length; j++)
            {
                uv[corner[j]].x = 0.5f * (vertices[corner[j]].z + 1f);
                uv[corner[j]].y = .5f * (1 + vertices[corner[j]].y);
            }
        }
    }
    private void Update()
    {
        if (roundRadius != oldRoundRadius)
        {
            for (int i = 0; i < sectionCorners.Length; i++)
            {
                RoundCorner(i, roundRadius);
            }
            oldRoundRadius = roundRadius;
            GenerateBody();
            ApplyVertices();
            CorrectUVs();
            ApplyUVs();
            ApplyMesh();
        }
    }


    void OnDrawGizmos()
    {
        if (VertiStr == "")
        {
            VertiStr = "";
            for (int i = 0; i < mesh.uv.Length; i += 1)
            {
                var a = mesh.uv[i];
                VertiStr += "new Vector2(" + a.x + "f," + a.y + "),";
            }
            Debug.Log(VertiStr);
        }
        if (VertiStr == "")
        {
            //string path = @"E:\verts.txt";
            //FileStream fs;
            //if (!File.Exists(path))
            //    File.Create(path).Dispose();
            //fs = File.OpenRead(path);
            VertiStr = "";
            for (int i = 0; i < mesh.vertices.Length; i += 1)
            {
                VertiStr += "new Vector3" + mesh.vertices[i] + ",";
            }
            VertiStr = VertiStr.Replace(",", "f,");
            VertiStr = VertiStr.Replace(")f,", "f),");
            VertiStr = VertiStr.Replace("0.3", "0.3333333");
            VertiStr = VertiStr.Replace("0.7", "0.6666666");
            Debug.Log(VertiStr);
        }
        if (VertiStr == "")
        {
            VertiStr = "";
            for (int i = 0; i < mesh.triangles.Length; i += 3)
            {
                VertiStr += "" + mesh.triangles[i] + "," + mesh.triangles[i + 1] + "," + mesh.triangles[i + 2] + ",\n";
            }
            Debug.Log(VertiStr);
        }

        Gizmos.color = Color.green;
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            Vector3 targetPosition = transform.TransformPoint(mesh.vertices[i]);
            Gizmos.DrawSphere(targetPosition, 0.05f);
        }
        Gizmos.color = Color.red;
        for (int i = 0; i < mesh.normals.Length; i++)
        {

            Vector3 targetPosition = transform.TransformPoint(mesh.normals[i]);

            Gizmos.DrawLine(Vector3.one * 0.25f * i, targetPosition);
        }
    }

    private void OnGUI()
    {
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            Vector3 targetPosition = transform.TransformPoint(mesh.vertices[i]);
            var pos = Camera.main.WorldToScreenPoint(targetPosition);
            GUI.Label(new Rect(pos.x, Screen.height - pos.y, 32, 32), "" + i);
            var st = new GUIStyle();
            st.alignment = TextAnchor.MiddleCenter;
            st.fontStyle = FontStyle.Bold;
            st.normal.textColor = Color.red;
            st.fontSize = 18;
            GUI.Box(new Rect(pos.x - 2, Screen.height - pos.y, 8, 8), "*", st);
        }
    }

}