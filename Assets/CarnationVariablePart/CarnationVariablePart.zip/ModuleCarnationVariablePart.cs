﻿using System;
using System.IO;
using System.Reflection;
using UnityEngine;
using KSP;
namespace CarnationVariableSectionPart
{       
    public class ModuleCarnationVariablePart : PartModule
    {
         public static int CVSPEditorLayer;
        public string EndTexName { get; set; } = "end.png";
        public string SideTexName { get; set; } = "side.png";
        public bool UseEndTexture { get; set; } = true;
        public bool UseSideTexture { get; set; } = true;
        public bool RealWorldMapping { get; set; } = false;
        public bool CornerUVCorrection { get; set; } = true;
        public bool SectionTiledMapping { get; set; } = false;
        private Texture endTexture;
        private Texture sideTexture;
        private Texture endNormTexture;
        private Texture sideNormTexture;
        private CVSPParameters _Parameter;
        private Renderer _MeshRender;
        private MeshFilter mf;
        private bool editing = false;
        private bool startEdit = false;
        private GameObject model;//in-game hierachy: Part(which holds PartModule)->model(dummy node)->$model name$(which holds actual mesh, renderers and colliders)

         public Renderer MeshRender
        {
            get
            {
                if (_MeshRender == null)
                {
                    _MeshRender = Model.GetComponent<Renderer>();
                    if (_MeshRender == null)
                        Debug.Log("[CarnationVariableSectionPart] No Mesh Renderer found");
                }
                return _MeshRender;
            }
        }

        public CVSPParameters Parameter
        {
            get
            {
                if (_Parameter == null)
                    _Parameter = new CVSPParameters(mf);
                return _Parameter;
            }
            private set => _Parameter = value;
        }

        public GameObject Model
        {
            get
            {
                if (model == null)
                {
                    if (HighLogic.LoadedSceneIsEditor)
                        model = GetComponentInChildren<MeshFilter>().gameObject;
                    if (model == null)
                        Debug.Log("[CarnationVariableSectionPart] No Mesh Filter found");
                }
                return model;
            }
        }

        public Texture EndTexture { get => endTexture; set => endTexture = value; }
        public Texture SideTexture { get => sideTexture; set => sideTexture = value; }
        public Texture EndNormTexture { get => endNormTexture; set => endNormTexture = value; }
        public Texture SideNormTexture { get => sideNormTexture; set => sideNormTexture = value; }

        private void Start()
        {if (!HighLogic.LoadedSceneIsEditor) return;
            //使用旧版兼容的方法
            mf = Model.GetComponent<MeshFilter>();
            if (mf != null)
            {
                Debug.Log("[CarnationVariableSectionPart] MU model verts:" + mf.sharedMesh.vertices.Length + "tris:" + mf.sharedMesh.triangles.Length / 3 + ", submeh:" + mf.sharedMesh.subMeshCount);

                //CVSPParameters.Destroy(mf);
                //mf = Model.AddComponent<MeshFilter>();
            }
            else
                Debug.Log("[CarnationVariableSectionPart] No Mesh Filter on module's gameobject");

            Debug.Log("[CarnationVariableSectionPart] Module's gameobject:" + gameObject.name + ", child 0's:" + transform.GetChild(0).childCount);
            Transform t = transform;
            for (int i = 0; i < t.childCount; i++)
            {
                var tt = t.GetChild(i);
                Debug.Log("[CarnationVariableSectionPart] VSPart->:" + tt.name + ", c counts:" + tt.childCount);
            }
            Component[] t1 = transform.GetChild(0).GetChild(0).GetComponents<Component>();
            foreach (var item in t1)
            {
                Debug.Log("[CarnationVariableSectionPart] VSPart->model->Mu model->:" + " (" + item.GetType().Name);
            }
            LoadTexture();
            UpdateMaterials();

            if (HighLogic.LoadedSceneIsEditor)
            {
                GameEvents.onEditorPartEvent.Add(OnPartEvent);
                SetLayer4Raycast();
            }
        }
        void SetLayer4Raycast()
        {
            //   CVSPEditorLayer = part.gameObject.layer;//27: WheelColliders
        }
        private void OnDestroy()
        {
            CVSPEditorTool.OnPartDestroyed();
            //throws exception when program killed
            Debug.Log("[CarnationVariableSectionPart] Part Module Destroyed!!!!!!!");
            GameEvents.onEditorPartEvent.Remove(OnPartEvent);
        }
        private void OnPartEvent(ConstructionEventType type, Part p)
        {
            if (p.persistentId == part.persistentId)
            {
                if (type == ConstructionEventType.PartDetached || type == ConstructionEventType.PartPicked)
                {
                    CVSPEditorTool.Instance.Deactivate();
                }
            }
        }
        private void LoadTexture()
        {
            string path = @"file://" + CVSPEditorTool.AssemblyPath;
            path = path.Remove(path.LastIndexOf("Plugins")) + @"Texture" + Path.DirectorySeparatorChar;
            SideTexture = LoadTexture(path + SideTexName);
            EndTexture = LoadTexture(path + EndTexName);
            var suffix = SideTexName.Substring(SideTexName.LastIndexOf('.'));
            SideNormTexture = LoadTexture(path + SideTexName.Remove(SideTexName.LastIndexOf('.')) + "_n" + suffix);
            suffix = EndTexName.Substring(EndTexName.LastIndexOf('.'));
            EndNormTexture = LoadTexture(path + EndTexName.Remove(EndTexName.LastIndexOf('.')) + "_n" + suffix);
        }
        private Texture LoadTexture(string path)
        {
            WWW w = new WWW(path);
            Texture2D t2d = w.texture;
            if (t2d == null)
            {
                Debug.LogError("[CarnationVariableSectionPart] Can't load Texture");
                return null;
            }
            w.Dispose();
            return t2d;
        }
        private void Update()
        {
            if (HighLogic.LoadedSceneIsEditor)
            {
                if (editing)
                {
                    if (Parameter.SthChanged || startEdit)
                    {
                        UpdateMaterials();
                        Parameter.UpdateGeometry();
                        startEdit = false;
                    }
                }
                if (Input.GetKeyDown(KeyCode.P))
                {
                    SetLayer4Raycast();
                    CVSPEditorTool.TryActivate();
                }
            }
        }
        public void OnEndEditing()
        {
            editing = true;
            startEdit = false;
            if (_Parameter != null)
            {
                CVSPParameters.Destroy(_Parameter);
                _Parameter = null;
            }
        }
        public void OnStartEditing()
        {
            editing = true;
            startEdit = true;
            Parameter.Secttion0Transform.localPosition = Vector3.zero;
            Parameter.Secttion1Transform.localPosition = Vector3.zero;
        }
        private void UpdateMaterials()
        {
            if (MeshRender != null)
            {
                if (MeshRender.sharedMaterials.Length != 2)
                    MeshRender.sharedMaterials = new Material[2]{
                    new Material(CVSPEditorTool.BumpedShader){ color=new Color(.5f,.5f,.5f)},
                    new Material(CVSPEditorTool.BumpedShader){ color=new Color(.5f,.5f,.5f)} };
                if (UseEndTexture)
                {
                    if (MeshRender.sharedMaterials[0].mainTexture == null)
                    {
                        MeshRender.sharedMaterials[0].mainTexture = EndTexture;
                        MeshRender.sharedMaterials[0].SetTexture("_BumpMap", EndNormTexture);
                    }
                }
                else
                {
                    MeshRender.sharedMaterials[0].mainTexture = null;
                    MeshRender.sharedMaterials[0].SetTexture("_BumpMap", null);
                }
                if (UseSideTexture)
                {
                    if (MeshRender.sharedMaterials[1].mainTexture == null)
                    {
                        MeshRender.sharedMaterials[1].mainTexture = SideTexture;
                        MeshRender.sharedMaterials[1].SetTexture("_BumpMap", SideNormTexture);
                    }
                }
                else
                {
                    MeshRender.sharedMaterials[1].mainTexture = null;
                    MeshRender.sharedMaterials[1].SetTexture("_BumpMap", null);
                }
            }
        }

        private void OnGUI()
        {
            GUILayout.BeginArea(new Rect(Screen.width - 300, 300, 300, 500));
            GUILayout.BeginHorizontal();
            GUILayout.Label($"x:{transform.position.x},y:{transform.position.y},z:{transform.position.z}");
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            s = GUILayout.TextField(s);
            if (GUILayout.Button("Set GUIStyle"))
                Node.SetStyle(s);
            GUILayout.EndHorizontal();
            GUILayout.EndArea();


            var t = transform.root;
            GUI.Label(new Rect(250, 80, 80, 20), t.name);
            var ts = t.GetComponentsInChildren<Transform>();
            var total = ts.Length;
            nodes = new Node[total];
            for (int i = 0; i < total; i++)
                nodes[i] = new Node(ts[i]);
            foreach (var i in nodes)
                if (i.parent == null)
                    foreach (var j in nodes)
                        if (j.t == i.t.parent)
                            i.parent = j;
            foreach (var i in nodes)
            {
                var ct = i.parent;
                while (ct != null)
                {
                    ct.subtreeH += lineH;
                    ct = ct.parent;
                }
            }
            ancx = 50;
            ancy = 100;
            x = new int[16];
            y = new int[16];
            for (int i = 0; i < nodes.Length; i++)
            {
                var n = nodes[i];
                if (null != n.parent)
                    if (n.parent.t == t)
                        if (!n.drawed)
                            n.DrawSelfAndChilds();
            }

        }
        static int lineH = 20, colW = 220;
        private static Node[] nodes;
        private static int[] x;
        private static int[] y;
        private static int ancx;
        private static int ancy;
        private static string s = "";

        class Node
        {
            public Transform t;
            public int subtreeH, lvl;
            public Node parent;
            public bool drawed;
            static Texture2D bg = new Texture2D(4, 4);
            public static GUIStyle wrap;
            static Node()
            {
                bg.SetPixels(new Color[] { new Color(0, 0, 0, .2f), new Color(0, 0, 0, .2f), new Color(0, 0, 0, .2f), new Color(0, 0, 0, .2f) });
                wrap = new GUIStyle() { wordWrap = true, normal = new GUIStyleState() { background = bg } };
                wrap = new GUIStyle("textarea");
                wrap.wordWrap = true;
            }
            public static void SetStyle(string s)
            {
                wrap = new GUIStyle(s);
                wrap.wordWrap = true;
            }
            public Node(Transform tt)
            {
                t = tt;
                subtreeH = 0;
                lvl = 0;
                drawed = false;
                var ct = t;
                while (ct.parent)
                {
                    ct = ct.parent;
                    lvl++;
                }
            }
            public void DrawSelfAndChilds()
            {
                var s = "|" + (t.GetComponent<MeshFilter>() ? "Mf" : "")
                          + (t.GetComponent<MeshRenderer>() ? "Mr" : "")
                          + (t.GetComponent<PartModule>() ? "Pm" : "")
                          + (t.GetComponent<HandleGizmo>() ? "Hg" : "")
                    ;
                if (s.Length == 1) s = "";
                if (subtreeH == 0) subtreeH = lineH;
                var rct = new Rect(ancx + lvl * colW, ancy + y[lvl], colW, subtreeH);
                GUI.Box(rct, t.name + s, wrap); ;
                y[lvl] += subtreeH;
                drawed = true;
                for (int i = 0; i < nodes.Length; i++)
                {
                    var n = nodes[i];
                    if (!n.drawed && null != n.parent)
                        if (n.parent == this)
                            n.DrawSelfAndChilds();
                }
            }
        }
        void OnStart()
        {

        }
    }
}