﻿using System;
using UnityEngine;
using System.Threading;
using System.Collections.Generic;

namespace CarnationVariableSectionPart
{
    public partial class CVSPParameters
    {
        private static float MaxSize = 20f;
        public float Section0Width
        {
            get => _Section0Width;
            set
            {
                _Section0Width = Mathf.Min(Mathf.Max(0, value), MaxSize);
                SthChanged = true;
            }
        }
        public float Section0Height
        {
            get => _Section0Height;
            set
            {
                _Section0Height = Mathf.Min(Mathf.Max(0, value), MaxSize);
                SthChanged = true;
            }
        }
        public float Section1Width
        {
            get => _Section1Width;
            set
            {
                _Section1Width = Mathf.Min(Mathf.Max(0, value), MaxSize);
                SthChanged = true;
            }
        }
        public float Section1Height
        {
            get => _Section1Height;
            set
            {
                _Section1Height = Mathf.Min(Mathf.Max(0, value), MaxSize);
                SthChanged = true;
            }
        }
        public float Length
        {
            get => _Length;
            set
            {
                _Length = Mathf.Min(Mathf.Max(value, 0.001f), MaxSize);
                SthChanged = true;
            }
        }
        /// <summary>
        /// Along width
        /// </summary>
        public float Run
        {
            get => _Run;
            set
            {
                _Run = Mathf.Min(value, MaxSize);
                SthChanged = true;
            }
        }
        /// <summary>
        /// Along height
        /// </summary>
        public float Raise
        {
            get => _Raise;
            set
            {
                _Raise = Mathf.Min(value, MaxSize);
                SthChanged = true;
            }
        }
        public float Twist
        {
            get => _Twist;
            set
            {
                _Twist = Mathf.Clamp(value, -45f, 45f);
                SthChanged = true;
            }
        }
        public Transform Secttion1Transform
        {
            get => secttion1Transform;

            private set => secttion1Transform = value;
        }
        public Transform Secttion0Transform
        {
            get => secttion0Transform;
            private set => secttion0Transform = value;
        }
        private float[] oldCornerRadius = new float[8];
        public float[] CornerRadius
        {
            get => meshBuilder.RoundRadius;
            set
            {
                meshBuilder.RoundRadius = value;
                SthChanged = true;
            }
        }
        public bool CornerUVCorrection
        {
            get => _CornerUVCorrection; set
            {
                _CornerUVCorrection = value;
                SthChanged = true;
            }
        }
        public bool RealWorldMapping
        {
            get => _RealWorldMapping; set
            {
                _RealWorldMapping = value;
                SthChanged = true;
            }
        }
        public bool SectionTiledMapping
        {
            get => _SectionTiledMapping; set
            {
                _SectionTiledMapping = value;
                SthChanged = true;
            }
        }
        public float SideUVOffestU
        {
            get => _SideUVOffestU; set
            {
                _SideUVOffestU = value;
                SthChanged = true;
            }
        }
        public float SideUVOffestV
        {
            get => _SideUVOffestV; set
            {
                _SideUVOffestV = value;
                SthChanged = true;
            }
        }
        public float EndUVOffestU
        {
            get => _EndUVOffestU; set
            {
                _EndUVOffestU = value;
                SthChanged = true;
            }
        }
        public float EndUVOffestV
        {
            get => _EndUVOffestV; set
            {
                _EndUVOffestV = value;
                SthChanged = true;
            }
        }
        public float SideUVScaleU
        {
            get => _SideUVScaleU;
            set
            {
                _SideUVScaleU = value;
            }
        }
        public float SideUVScaleV
        {
            get => _SideUVScaleV;
            set
            {
                _SideUVScaleV = value;
                SthChanged = true;
            }
        }
        public float EndUVScaleU
        {
            get => _EndUVScaleU;
            set
            {
                _EndUVScaleU = value;
                SthChanged = true;
            }
        }
        public float EndUVScaleV
        {
            get => _EndUVScaleV; set
            {
                _EndUVScaleV = value;
                SthChanged = true;
            }
        }

        public bool SthChanged { get => _SthChanged; private set => _SthChanged = value; }

        [NonSerialized]
        CVSPMeshBuilder meshBuilder;
        delegate void DelUpdate();
        static DelUpdate del;
        private bool requestUpdate = false;
        private bool _SthChanged = true;

        private float _Twist;
        private float _Section0Width;
        private float _Section0Height;
        private float _Section1Width;
        private float _Section1Height;
        private float _oldSection0Width;
        private float _oldSection0Height;
        private float _oldSection1Width;
        private float _oldSection1Height;
        private float _Length;
        private float _Run;
        private float _Raise;
        private bool _CornerUVCorrection;
        private bool _RealWorldMapping;
        private bool _SectionTiledMapping;
        private float _SideUVOffestU;
        private float _SideUVOffestV;
        private float _EndUVOffestU;
        private float _EndUVOffestV;
        private float _SideUVScaleU;
        private float _SideUVScaleV;
        private float _EndUVScaleU;
        private float _EndUVScaleV;
        private Transform secttion1Transform;
        private Transform secttion0Transform;
        private GameObject sec0, sec1;

        static CVSPParameters()
        {
            //del = new DelUpdate(UpdateQueue);
            //  del.BeginInvoke(null, null);
        }
        public static new void Destroy(object o)
        {
            if (o is CVSPParameters) { 
                ((CVSPParameters)o).OnDestroy();
            }
            else if (o is UnityEngine.Object)
                UnityEngine.Object.Destroy((UnityEngine.Object)o);
        }

        private void OnDestroy()
        {
            meshBuilder = null;
            Destroy(sec0);
            Destroy(sec1);
        }

        public CVSPParameters(MeshFilter mf)
        {
            if (sec0 == null)
            {
                sec0 = new GameObject("section0node");
                sec0.transform.SetParent(mf.transform,false);
            }
            if (sec1 == null)
            {
                sec1 = new GameObject("section1node");
                sec1.transform.SetParent(mf.transform,false);
            }
            secttion0Transform = sec0.transform;
            secttion1Transform = sec1.transform;

            meshBuilder = new CVSPMeshBuilder(mf, this);
            if (meshBuilder == null) throw new Exception();
            LoadParams();
            UpdateGeometry();
        }

        private void LoadParams()
        {
            Length = 2f;
            Section0Width = 2;
            Section1Height = 2;
            Section1Width = 2;
            Section0Height = 2;
            Run = 0;
            Raise = 0;
            Twist = 0;
            for (int i = 0; i < CornerRadius.Length; i++)
                CornerRadius[i] = 1;
        }
        public void MakeDynamic()
        {
            meshBuilder.MakeDynamic();
        }
        public void UpdateGeometry()
        {
            if (meshBuilder == null) return;
            if (!SthChanged)
                for (int i = 0; i < CornerRadius.Length; i++)
                    if (CornerRadius[i] != oldCornerRadius[i])
                    {
                        SthChanged = true;
                        break;
                    }
            if (SthChanged)
            {
                for (int i = 0; i < CornerRadius.Length; i++)
                {
                    CornerRadius[i] = Mathf.Clamp(CornerRadius[i], 0, 1f);
                    oldCornerRadius[i] = CornerRadius[i];
                }
                requestUpdate = true;
                meshBuilder.Update();
                Secttion1Transform.localRotation = Quaternion.Euler(-Twist, 180f, 0);
                Secttion1Transform.localPosition = Secttion1Transform.localRotation * new Vector3(Length, Raise, -Run);
                Secttion0Transform.localPosition = Vector3.zero;
                Secttion0Transform.localRotation = Quaternion.identity;
                SthChanged = false;
            }
        }
            }
}